package com.example.recyclerviewkotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.recyclerviewkotlin.R
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private var listaPersonajes: MutableList<Personajes>? = null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listaPersonajes = mutableListOf<Personajes>()
        val recyclerView = findViewById(R.id.recyclerView) as RecyclerView

        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayout.VERTICAL, false)

        conectarJson()

    }

    fun conectarJson() {
        var listaPersonajes = ArrayList<Personajes>()
        val url = "http://iesayala.ddns.net/isacra/"
        val queue = Volley.newRequestQueue(this)
        val stringRequest = StringRequest(Request.Method.GET, url, Response.Listener { response ->

            val jsonArray = JSONArray(response)
            for (i in 0..jsonArray.length()-1) {
                val jsonObject = JSONObject(jsonArray.getString(i));
                val personaje = Personajes(jsonObject.getString("Nombre"),jsonObject.getString("Apellidos"),jsonObject.getString("Imagen"),jsonObject.getString("Telefono"),jsonObject.getString("Raza"),jsonObject.getString("Clase"))

                listaPersonajes!!.add(personaje)
            }
            val adapter = AdaptadorPersonajes(listaPersonajes)
            recyclerView.addItemDecoration(DividerItemDecoration(this, DividerItemDecoration.VERTICAL))
            recyclerView.adapter=adapter
        }, Response.ErrorListener {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show()
        })

        queue!!.add(stringRequest)
    }


}