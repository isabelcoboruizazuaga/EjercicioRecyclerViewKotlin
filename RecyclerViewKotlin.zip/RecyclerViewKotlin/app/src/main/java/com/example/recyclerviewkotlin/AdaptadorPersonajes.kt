package com.example.recyclerviewkotlin

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.recyclerviewkotlin.R


class AdaptadorPersonajes(val listaPersonajes: ArrayList<Personajes>) :
    RecyclerView.Adapter<AdaptadorPersonajes.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdaptadorPersonajes.ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.lista_personajes, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: AdaptadorPersonajes.ViewHolder, position: Int) {
        holder.bindItems(listaPersonajes[position])
    }

    override fun getItemCount(): Int {
        return listaPersonajes.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bindItems(personajes: Personajes) {
            val textView = itemView.findViewById(R.id.textView3) as TextView

            val imagen = itemView.findViewById(R.id.imageView) as ImageView
            textView.text = personajes.nombre+"\n"+personajes.apellidos+"\n"
            Glide.with(itemView).load(personajes.imagen).into(imagen)

            textView.setOnClickListener {
                Toast.makeText(itemView.context,"El telefono es "+personajes.telefono, Toast.LENGTH_SHORT).show();
            }

            imagen.setOnClickListener {
                val intent = Intent(itemView.context,PersonajesInformacion::class.java)
                intent.putExtra("nombre",personajes.nombre)
                intent.putExtra("apellidos",personajes.apellidos)
                intent.putExtra("imagen",personajes.imagen)
                intent.putExtra("clase",personajes.clase)
                intent.putExtra("raza",personajes.raza)

                itemView.context.startActivity(intent)
            }

        }
    }

}

