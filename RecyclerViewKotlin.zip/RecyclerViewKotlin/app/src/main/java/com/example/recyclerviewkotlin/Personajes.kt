package com.example.recyclerviewkotlin




class Personajes(var nombre: String, var apellidos: String, var imagen :String,var telefono :String,var raza :String,var clase :String)




